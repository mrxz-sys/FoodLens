/* ═══════════════════════════════════════════
   FoodLens — app.js
   Open Food Facts barcode analyser
   Français / العربية / دارجة
═══════════════════════════════════════════ */

'use strict';

/* ── i18n ── */
const LANGS = {
  fr: {
    labelScan: 'Code-barres',
    scanBtn:   'Analyser',
    labelTry:  'Essayer :',
    emptyTitle:'Scannez un produit',
    emptySub:  'Entrez un code-barres pour obtenir une analyse complète en secondes.',
    verdict:   { good:'✅ Bon choix', ok:'⚠️ Acceptable', bad:'❌ À éviter' },
    sections:  { nutrition:'Valeurs nutritionnelles (pour 100 g)', warnings:'Alertes & Restrictions', ingredients:'Ingrédients', alternative:'Meilleure alternative' },
    warnings: {
      halal:        ['🚫 Non Halal détecté',    'Ce produit peut contenir du porc ou de l\'alcool.'],
      gluten:       ['🌾 Contient du Gluten',   'Non adapté aux personnes cœliaques.'],
      lactose:      ['🥛 Contient du Lactose',  'Peut provoquer des inconforts chez les intolérants.'],
      pork:         ['🐷 Dérivés de porc',      'Gélatine ou graisses animales porcines détectées.'],
      ultra:        ['⚠️ Ultra-transformé (NOVA 4)', 'Additifs, conservateurs et arômes artificiels.'],
      ok_halal:     ['✅ Probablement Halal',   'Aucun ingrédient porcin ou alcool détecté.'],
      high_sodium:  ['🧂 Très salé',            'Teneur en sel élevée, à consommer avec modération.'],
      high_satfat:  ['🧈 Graisses saturées',    'Taux élevé d\'acides gras saturés.'],
      high_additive:['🧪 Nombreux additifs',    'Colorants, conservateurs ou édulcorants détectés.'],
      low_calorie:  ['💧 Très peu calorique',   'Ce produit n\'apporte quasiment pas d\'énergie.'],
    },
    nutrients: { energy:'Énergie', sugars:'Sucres', fat:'Lipides', salt:'Sel', proteins:'Protéines', fiber:'Fibres', satfat:'Graisses sat.' },
    reasons: {
      high_sugar:   (v) => `Trop sucré — ${v.toFixed(1)} g de sucres/100 g`,
      high_fat:     (v) => `Trop gras — ${v.toFixed(1)} g de lipides/100 g`,
      high_satfat:  (v) => `Graisses saturées élevées — ${v.toFixed(1)} g/100 g`,
      high_salt:    (v) => `Trop salé — ${v.toFixed(1)} g de sel/100 g`,
      ultra:        ()  => 'Aliment ultra-transformé (NOVA 4)',
      good_prot:    (v) => `Bonne source de protéines — ${v.toFixed(1)} g/100 g`,
      balanced:     ()  => 'Profil nutritionnel équilibré',
      low_calorie:  ()  => 'Produit très peu calorique (eau, sauce légère…)',
      default:      ()  => 'Vérifiez les détails ci-dessous',
    },
    alt_title:    'Alternative recommandée',
    alt_loading:  'Recherche en cours…',
    alt_none:     'Aucune alternative trouvée',
    not_found:    'Produit introuvable.\nVérifiez le code-barres ou essayez un autre produit.',
    net_error:    'Erreur réseau — vérifiez votre connexion.',
    nova_labels:  ['', 'Peu transformé', 'Ingrédients culinaires', 'Transformé', 'Ultra-transformé'],
    dir: 'ltr',
  },
  ar: {
    labelScan: 'الباركود',
    scanBtn:   'تحليل',
    labelTry:  'جرّب :',
    emptyTitle:'امسح منتجاً',
    emptySub:  'أدخل الباركود للحصول على تحليل كامل في ثوانٍ.',
    verdict:   { good:'✅ اختيار جيد', ok:'⚠️ مقبول', bad:'❌ تجنّبه' },
    sections:  { nutrition:'القيم الغذائية (لكل 100 غ)', warnings:'تحذيرات وقيود', ingredients:'المكونات', alternative:'بديل أفضل' },
    warnings: {
      halal:        ['🚫 غير حلال',        'قد يحتوي على لحم الخنزير أو الكحول.'],
      gluten:       ['🌾 يحتوي على الغلوتين','غير مناسب لمرضى الداء البطني.'],
      lactose:      ['🥛 يحتوي على اللاكتوز','قد يسبب عسراً هضمياً للحساسين.'],
      pork:         ['🐷 مشتقات الخنزير',  'تم الكشف عن جيلاتين أو دهون خنزير.'],
      ultra:        ['⚠️ معالج بشدة (NOVA 4)','يحتوي على مضافات وأصباغ صناعية.'],
      ok_halal:     ['✅ على الأرجح حلال', 'لم يتم الكشف عن مكونات خنزير أو كحول.'],
      high_sodium:  ['🧂 ملح مرتفع',       'محتوى ملح عالٍ، يُنصح بالاعتدال.'],
      high_satfat:  ['🧈 دهون مشبعة',      'نسبة عالية من الأحماض الدهنية المشبعة.'],
      high_additive:['🧪 مضافات كثيرة',    'ملونات أو حوافظ أو محليات صناعية.'],
      low_calorie:  ['💧 منخفض السعرات',   'هذا المنتج يكاد لا يحتوي على طاقة.'],
    },
    nutrients: { energy:'طاقة', sugars:'سكريات', fat:'دهون', salt:'ملح', proteins:'بروتين', fiber:'ألياف', satfat:'دهون مشبعة' },
    reasons: {
      high_sugar:   (v) => `سكر مرتفع — ${v.toFixed(1)} غ/100 غ`,
      high_fat:     (v) => `دهون مرتفعة — ${v.toFixed(1)} غ/100 غ`,
      high_satfat:  (v) => `دهون مشبعة — ${v.toFixed(1)} غ/100 غ`,
      high_salt:    (v) => `ملح زائد — ${v.toFixed(1)} غ/100 غ`,
      ultra:        ()  => 'غذاء مُعالَج بشدة (NOVA 4)',
      good_prot:    (v) => `غني بالبروتين — ${v.toFixed(1)} غ/100 غ`,
      balanced:     ()  => 'قيم غذائية متوازنة',
      low_calorie:  ()  => 'منتج منخفض السعرات جداً (ماء، صلصة خفيفة…)',
      default:      ()  => 'راجع التفاصيل أدناه',
    },
    alt_title:    'بديل مقترح',
    alt_loading:  'جارٍ البحث…',
    alt_none:     'لم يُعثر على بديل',
    not_found:    'المنتج غير موجود.\nتحقق من الباركود أو جرّب منتجاً آخر.',
    net_error:    'خطأ في الشبكة — تحقق من اتصالك.',
    nova_labels:  ['', 'طبيعي', 'مكونات طهي', 'مُعالَج', 'مُعالَج بشدة'],
    dir: 'rtl',
  },
  dr: {
    labelScan: 'الباركود',
    scanBtn:   'حلّل',
    labelTry:  'جرّب :',
    emptyTitle:'سكان شي منتوج',
    emptySub:  'دخل الباركود باش تشوف التحليل الكامل ف ثواني.',
    verdict:   { good:'✅ خيار مزيان', ok:'⚠️ مقبول', bad:'❌ خليه' },
    sections:  { nutrition:'القيم الغذائية (ل 100 غ)', warnings:'تحذيرات وقيود', ingredients:'المكونات', alternative:'بديل أحسن' },
    warnings: {
      halal:        ['🚫 مشي حلال',      'ممكن فيه خنزير ولا كحول.'],
      gluten:       ['🌾 فيه جلوتين',    'مشي مناسب لمن عندهم حساسية.'],
      lactose:      ['🥛 فيه لاكتوز',    'ممكن يولد مشاكل لي عندهم عدم تحمل.'],
      pork:         ['🐷 فيه خنزير',     'كاين جيلاتين ولا دهون الخنزير.'],
      ultra:        ['⚠️ مصنّع بزاف (NOVA 4)','فيه ملونات وحوافظ ومواد صناعية.'],
      ok_halal:     ['✅ غالباً حلال',   'ما تلقاوش خنزير ولا كحول.'],
      high_sodium:  ['🧂 فيه ملح بزاف', 'كمية الملح عالية، خودها بالقدر.'],
      high_satfat:  ['🧈 دهون مشبعة',   'نسبة عالية من الدهون المشبعة.'],
      high_additive:['🧪 فيه مضافات',   'ملونات ولا حوافظ ولا محليات صناعية.'],
      low_calorie:  ['💧 سعرات قليلة',  'هاد المنتوج ما فيهش تقريباً شي طاقة.'],
    },
    nutrients: { energy:'طاقة', sugars:'سكر', fat:'دهون', salt:'ملح', proteins:'بروتين', fiber:'ألياف', satfat:'دهون مشبعة' },
    reasons: {
      high_sugar:   (v) => `فيه سكر بزاف — ${v.toFixed(1)} غ/100 غ`,
      high_fat:     (v) => `فيه دهون بزاف — ${v.toFixed(1)} غ/100 غ`,
      high_satfat:  (v) => `دهون مشبعة — ${v.toFixed(1)} غ/100 غ`,
      high_salt:    (v) => `فيه ملح بزاف — ${v.toFixed(1)} غ/100 غ`,
      ultra:        ()  => 'منتوج مصنّع بزاف (NOVA 4)',
      good_prot:    (v) => `غني بالبروتين — ${v.toFixed(1)} غ/100 غ`,
      balanced:     ()  => 'قيم غذائية متوازنة',
      low_calorie:  ()  => 'منتوج ما فيهش سعرات (ماء، صلصة خفيفة…)',
      default:      ()  => 'شوف التفاصيل من تحت',
    },
    alt_title:    'بديل مقترح',
    alt_loading:  'كنقلب…',
    alt_none:     'ما لقيناش بديل',
    not_found:    'ما تلقيناشه.\nتأكد من الباركود ولا جرب منتوج آخر.',
    net_error:    'خطأ ف الاتصال — تحقق من النت ديالك.',
    nova_labels:  ['', 'طبيعي', 'مكونات الطبخ', 'مصنّع', 'مصنّع بزاف'],
    dir: 'rtl',
  },
};

let lang = 'fr';
let lastProduct = null;

/* ── Helpers ── */
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

function setLang(l) {
  lang = l;
  const L = LANGS[l];
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === l));
  document.documentElement.setAttribute('dir', L.dir);
  $('labelScan').textContent    = L.labelScan;
  $('scanBtnText').textContent  = L.scanBtn;
  $('labelTry').textContent     = L.labelTry;
  $('emptyTitle').textContent   = L.emptyTitle;
  $('emptySub').textContent     = L.emptySub;
  if (lastProduct) renderProduct(lastProduct);
}

/* ── Scan ── */
async function handleScan() {
  const barcode = $('barcodeInput').value.trim().replace(/\s/g, '');
  if (!barcode) return;

  const loadingBar = $('loadingBar');
  const btn        = $('scanBtn');
  const spinner    = $('spinner');
  const scanText   = $('scanBtnText');
  const resultArea = $('resultArea');
  const emptyState = $('emptyState');

  loadingBar.classList.add('active');
  btn.disabled = true;
  spinner.classList.add('active');
  scanText.classList.add('scan-btn-text-hidden');
  emptyState.classList.add('empty-state-hidden');
  resultArea.classList.remove('visible');
  resultArea.innerHTML = '';

  try {
    const res = await fetch(
      `https://world.openfoodfacts.org/api/v0/product/${encodeURIComponent(barcode)}.json`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    if (data.status !== 1 || !data.product) {
      showError(LANGS[lang].not_found);
      return;
    }

    lastProduct = data.product;
    renderProduct(data.product);

  } catch (e) {
    showError(e.name === 'TimeoutError' ? LANGS[lang].net_error : LANGS[lang].not_found);
  } finally {
    loadingBar.classList.remove('active');
    btn.disabled = false;
    spinner.classList.remove('active');
    scanText.classList.remove('scan-btn-text-hidden');
  }
}

/* ── Error ── */
function showError(msg) {
  const resultArea = $('resultArea');
  resultArea.innerHTML = `<div class="error-card">${esc(msg).replace(/\n/g, '<br>')}</div>`;
  resultArea.classList.add('visible');
}

/* ══════════════════════════════════════════════
   VERDICT ENGINE
   Multi-factor scoring instead of nutriscore-only
══════════════════════════════════════════════ */
function computeVerdict(p) {
  const nutr    = p.nutriments || {};
  const nutri   = (p.nutriscore_grade || '').toUpperCase();
  const nova    = parseInt(p.nova_group) || 0;
  const ingr    = (p.ingredients_text || '').toLowerCase();

  const energy   = nutr['energy-kcal_100g'] ?? (nutr.energy_100g ? nutr.energy_100g / 4.184 : undefined);
  const sugar    = nutr.sugars_100g;
  const fat      = nutr.fat_100g;
  const satfat   = nutr['saturated-fat_100g'];
  const salt     = nutr.salt_100g;
  const sodium   = nutr.sodium_100g ?? (salt !== undefined ? salt / 2.5 : undefined);
  const proteins = nutr.proteins_100g;
  const fiber    = nutr.fiber_100g;

  /* ── Detect "near-zero nutrient" products (water, broth, light sauce…) ── */
  const totalNutrients = [sugar, fat, proteins].filter(v => v !== undefined);
  const sumNutrients   = totalNutrients.reduce((a, b) => a + b, 0);
  const isLowCalorie   = (energy !== undefined && energy < 15) ||
                         (totalNutrients.length >= 2 && sumNutrients < 2);

  /* ── Additive count heuristic (E-numbers in ingredients) ── */
  const additiveCount = (ingr.match(/\be\d{3,4}[a-z]?\b/g) || []).length;

  /* ── Build flag list ── */
  const flags = [];

  if (isLowCalorie)                                      flags.push('low_calorie');
  if (nova === 4)                                        flags.push('ultra');
  if (sugar  !== undefined && sugar  > 22)               flags.push('high_sugar');
  if (fat    !== undefined && fat    > 20)               flags.push('high_fat');
  if (satfat !== undefined && satfat > 10)               flags.push('high_satfat');
  if (salt   !== undefined && salt   > 1.5)              flags.push('high_salt');
  if (sodium !== undefined && sodium > 0.6 && !flags.includes('high_salt')) flags.push('high_sodium');
  if (additiveCount >= 4)                                flags.push('high_additive');

  /* ── Score (negative = bad) ── */
  let score = 0;

  // Nutriscore anchor (if available)
  const nutriScore = { A: 3, B: 2, C: 0, D: -2, E: -3 };
  if (nutri && nutriScore[nutri] !== undefined) score += nutriScore[nutri];

  // Penalties
  if (flags.includes('ultra'))        score -= 3;
  if (flags.includes('high_sugar'))   score -= 2;
  if (flags.includes('high_satfat'))  score -= 2;
  if (flags.includes('high_fat'))     score -= 1;
  if (flags.includes('high_salt'))    score -= 2;
  if (flags.includes('high_sodium'))  score -= 1;
  if (flags.includes('high_additive')) score -= 2;

  // Bonuses
  if (fiber    !== undefined && fiber    >= 3)  score += 1;
  if (proteins !== undefined && proteins >= 10) score += 1;
  if (nova >= 1 && nova <= 2)                   score += 1;

  // Low-calorie products (water, light sauces): treat as neutral
  if (flags.includes('low_calorie')) {
    return { verdictKey: 'ok', flags, energy, sugar, fat, satfat, salt, proteins, fiber,
             verdictReason: LANGS[lang].reasons.low_calorie() };
  }

  const verdictKey = score >= 3 ? 'good' : score >= 0 ? 'ok' : 'bad';

  /* ── Pick the most relevant reason ── */
  const R = LANGS[lang].reasons;
  const verdictReason =
    flags.includes('high_sugar')   ? R.high_sugar(sugar)   :
    flags.includes('ultra')        ? R.ultra()              :
    flags.includes('high_satfat')  ? R.high_satfat(satfat) :
    flags.includes('high_fat')     ? R.high_fat(fat)        :
    flags.includes('high_salt')    ? R.high_salt(salt)      :
    verdictKey === 'good' && proteins >= 10 ? R.good_prot(proteins) :
    verdictKey === 'good'          ? R.balanced()           :
    R.default();

  return { verdictKey, flags, energy, sugar, fat, satfat, salt, proteins, fiber, verdictReason };
}

/* ── Render ── */
function renderProduct(p) {
  const L    = LANGS[lang];
  const nutr = p.nutriments || {};
  const nutri = (p.nutriscore_grade || '').toUpperCase();
  const nova  = parseInt(p.nova_group) || 0;

  const { verdictKey, flags, energy, sugar, fat, satfat, salt, proteins, fiber, verdictReason }
    = computeVerdict(p);

  /* ── Ingredient flags ── */
  const ingr     = (p.ingredients_text || '').toLowerCase();
  const labels   = (p.labels_tags || []).join(' ');
  const allergens= (p.allergens_tags || []).join(' ');

  const hasPork    = /porc|pork|lard|gelatine|gélatine|saindoux|jambon/.test(ingr);
  const hasAlcohol = /alcool|alcohol|vin\b|bier|beer|wine/.test(ingr);
  const hasGluten  = /gluten|blé|wheat|orge|seigle|barley|rye|avoine/.test(ingr) || allergens.includes('gluten');
  const hasLactose = /\blait\b|milk|lactose|lactos|crème|cream|beurre|butter/.test(ingr) || allergens.includes('milk');
  const notHalal   = (hasPork || hasAlcohol) && !labels.includes('halal');

  /* ── Badges ── */
  const nutriBadge = nutri
    ? `<span class="badge badge-nutri-${nutri.toLowerCase()}">Nutri-Score ${nutri}</span>`
    : '';
  const novaLabel = nova ? L.nova_labels[Math.min(nova, 4)] : '';
  const novaBadge = nova
    ? `<span class="badge badge-nova-${Math.min(nova,4)}">NOVA ${nova} — ${esc(novaLabel)}</span>`
    : '';

  /* ── Product Image ── */
  const imgUrl = p.image_front_small_url || p.image_front_url || '';
  const imgHtml = imgUrl
    ? `<img class="product-image" src="${esc(imgUrl)}" alt="" loading="lazy">`
    : `<div class="product-no-image">🥫</div>`;

  /* ── Nutrition items ── */
  function barHtml(val, max, ok, warn) {
    if (val === undefined || val === null) return '';
    const pct = Math.min((val / max) * 100, 100).toFixed(1);
    const cls = val <= ok ? 'fill-green' : val <= warn ? 'fill-warn' : 'fill-red';
    return `<div class="nutr-bar"><div class="nutr-fill ${cls}" data-width="${pct}"></div></div>`;
  }
  function nutrItem(label, val, unit, max, ok, warn) {
    const display = (val !== undefined && val !== null) ? val.toFixed(1) : '—';
    return `
      <div class="nutr-item">
        <div class="nutr-label">${esc(label)}</div>
        <div class="nutr-value">${esc(display)}<span class="nutr-unit">${esc(unit)}</span></div>
        ${val !== undefined ? barHtml(val, max, ok, warn) : ''}
      </div>`;
  }

  const N = L.nutrients;
  const satfatVal = nutr['saturated-fat_100g'];

  /* ── Warning items ── */
  const warningItems = [];
  if (notHalal) warningItems.push({ type:'alert', key:'halal' });
  else          warningItems.push({ type:'ok',    key:'ok_halal' });
  if (hasPork && !notHalal)                warningItems.push({ type:'alert', key:'pork' });
  if (hasGluten)                           warningItems.push({ type:'alert', key:'gluten' });
  if (hasLactose)                          warningItems.push({ type:'alert', key:'lactose' });
  if (flags.includes('ultra'))             warningItems.push({ type:'alert', key:'ultra' });
  if (flags.includes('high_salt') || flags.includes('high_sodium'))
                                           warningItems.push({ type:'alert', key:'high_sodium' });
  if (flags.includes('high_satfat'))       warningItems.push({ type:'alert', key:'high_satfat' });
  if (flags.includes('high_additive'))     warningItems.push({ type:'alert', key:'high_additive' });
  if (flags.includes('low_calorie'))       warningItems.push({ type:'ok',    key:'low_calorie' });

  const warningsHtml = warningItems.map(w => {
    const [title, desc] = L.warnings[w.key] || ['?', ''];
    return `
      <div class="warning-item ${w.type === 'ok' ? 'warn-ok' : 'warn-alert'}">
        <div class="warning-dot ${w.type === 'ok' ? 'dot-green' : 'dot-red'}"></div>
        <div class="warning-text"><strong>${esc(title)}</strong>${esc(desc)}</div>
      </div>`;
  }).join('');

  /* ── Ingredients text ── */
  const ingText = p.ingredients_text
    ? `<div class="section-block">
        <div class="section-title">${esc(L.sections.ingredients)}</div>
        <div class="ingredients-box">
          <div class="ingredients-text">${esc(p.ingredients_text.slice(0, 400))}${p.ingredients_text.length > 400 ? '…' : ''}</div>
        </div>
       </div>`
    : '';

  /* ── Alternative placeholder (always shown, filled async) ── */
  const altHtml = `<div class="section-block">
      <div class="section-title">${esc(L.sections.alternative)}</div>
      <div class="alt-card" id="altCard" role="button" tabindex="0">
        <div class="alt-icon" id="altIcon">${getCategoryEmoji(p)}</div>
        <div class="alt-info">
          <div class="alt-title">${esc(L.alt_title)}</div>
          <div class="alt-name" id="altName">${esc(L.alt_loading)}</div>
          <div class="alt-brand" id="altBrand"></div>
        </div>
        <div class="alt-arrow">→</div>
      </div>
     </div>`;

  /* ── Assemble ── */
  const html = `
    <div class="product-header">
      ${imgHtml}
      <div class="product-info">
        <div class="product-name">${esc(p.product_name || p.product_name_fr || '—')}</div>
        <div class="product-brand">${esc(p.brands || '')}</div>
        <div class="badges-row">${nutriBadge}${novaBadge}</div>
      </div>
    </div>

    <div class="verdict-card verdict-${verdictKey}">
      <div class="verdict-label">${L.verdict[verdictKey]}</div>
      <div class="verdict-reason">${esc(verdictReason)}</div>
    </div>

    <div class="section-block">
      <div class="section-title">${esc(L.sections.nutrition)}</div>
      <div class="nutrition-grid">
        ${nutrItem(N.energy,   energy,   'kcal', 500,  200, 350)}
        ${nutrItem(N.sugars,   sugar,    'g',    50,   10,  22)}
        ${nutrItem(N.fat,      fat,      'g',    40,   10,  20)}
        ${nutrItem(N.satfat,   satfatVal,'g',    20,   5,   10)}
        ${nutrItem(N.salt,     salt,     'g',    3,    0.5, 1.5)}
        ${nutrItem(N.proteins, proteins, 'g',    30,   30,  30)}
        ${nutrItem(N.fiber,    fiber,    'g',    10,   5,   10)}
      </div>
    </div>

    <div class="section-block">
      <div class="section-title">${esc(L.sections.warnings)}</div>
      <div class="warnings-list">${warningsHtml}</div>
    </div>

    ${ingText}
    ${altHtml}
  `;

  const resultArea = $('resultArea');
  resultArea.innerHTML = html;
  resultArea.classList.add('visible');

  // Apply nutrition bar widths (avoids inline style CSP violation)
  resultArea.querySelectorAll('.nutr-fill[data-width]').forEach(el => {
    el.style.width = el.dataset.width + '%';
  });

  fetchAlternative(p);
}

/* ── Category emoji ── */
function getCategoryEmoji(p) {
  const cats = (p.categories_tags || []).join(' ');
  if (/beverage|boisson|drink|eau/.test(cats))        return '🥤';
  if (/chocolate|chocolat/.test(cats))                 return '🍫';
  if (/biscuit|cookie/.test(cats))                    return '🍪';
  if (/cereal|céréale/.test(cats))                    return '🥣';
  if (/dairy|lait|fromage|cheese/.test(cats))         return '🧀';
  if (/fruit/.test(cats))                             return '🍎';
  if (/pasta|pâte|spaghetti/.test(cats))              return '🍝';
  if (/bread|pain/.test(cats))                        return '🍞';
  if (/yogurt|yaourt/.test(cats))                     return '🥛';
  if (/sauce|condiment/.test(cats))                   return '🥫';
  if (/meat|viande|poultry/.test(cats))               return '🍖';
  if (/fish|poisson|seafood/.test(cats))              return '🐟';
  if (/vegetable|légume/.test(cats))                  return '🥦';
  return '🥗';
}

/* ══════════════════════════════════════════════
   FETCH ALTERNATIVE
   Tries multiple strategies until one works
══════════════════════════════════════════════ */
async function fetchAlternative(p) {
  const nameEl  = $('altName');
  const brandEl = $('altBrand');
  const card    = $('altCard');
  if (!nameEl) return;

  const L = LANGS[lang];

  // Build a priority list of category tags to try (most specific → least)
  const catTags = (p.categories_tags || []).slice(0, 5);

  // Strategy 1: search by category + nutriscore a or b (try each cat tag)
  for (const catTag of catTags) {
    const result = await tryFetchAlt(catTag, p.code, ['a', 'b']);
    if (result) {
      applyAlt(result, card, nameEl, brandEl);
      return;
    }
  }

  // Strategy 2: relax to nutriscore a/b/c with most popular cat tag
  for (const catTag of catTags.slice(0, 3)) {
    const result = await tryFetchAlt(catTag, p.code, ['a', 'b', 'c']);
    if (result) {
      applyAlt(result, card, nameEl, brandEl);
      return;
    }
  }

  // Strategy 3: top scanned products in the first category tag, any nutriscore
  if (catTags.length > 0) {
    const result = await tryFetchAlt(catTags[0], p.code, null);
    if (result) {
      applyAlt(result, card, nameEl, brandEl);
      return;
    }
  }

  // Nothing found
  nameEl.textContent  = L.alt_none;
  brandEl.textContent = '';
  if (card) card.style.cursor = 'default';
}

async function tryFetchAlt(catTag, excludeCode, nutriscoreGrades) {
  try {
    let url = `https://world.openfoodfacts.org/cgi/search.pl?action=process&json=1&page_size=20&sort_by=unique_scans_n`
      + `&tagtype_0=categories&tag_contains_0=contains&tag_0=${encodeURIComponent(catTag)}`;

    if (nutriscoreGrades && nutriscoreGrades.length === 1) {
      url += `&tagtype_1=nutrition_grades&tag_contains_1=contains&tag_1=${nutriscoreGrades[0]}`;
    }

    const res  = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = await res.json();

    const candidates = (data.products || []).filter(pr => {
      if (!pr.product_name || pr.code === excludeCode) return false;
      if (nutriscoreGrades) {
        return nutriscoreGrades.includes((pr.nutriscore_grade || '').toLowerCase());
      }
      return true;
    });

    return candidates.length > 0 ? candidates[0] : null;
  } catch (_) {
    return null;
  }
}

function applyAlt(alt, card, nameEl, brandEl) {
  nameEl.textContent  = alt.product_name;
  brandEl.textContent = alt.brands || '';
  if (card) {
    card.addEventListener('click', () => {
      $('barcodeInput').value = alt.code;
      handleScan();
    });
  }
}

/* ── Events ── */
$('barcodeInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') handleScan();
});

$('scanBtn').addEventListener('click', () => handleScan());

document.querySelectorAll('.example-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    $('barcodeInput').value = chip.dataset.barcode;
    handleScan();
  });
});

/* ── Save lang preference ── */
(function () {
  const saved = localStorage.getItem('foodlens_lang');
  if (saved && LANGS[saved]) setLang(saved);
})();

document.querySelectorAll('.lang-btn').forEach(b => {
  b.addEventListener('click', () => {
    setLang(b.dataset.lang);
    localStorage.setItem('foodlens_lang', b.dataset.lang);
  });
});
